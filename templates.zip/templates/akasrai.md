<h3 align="center"> Hi there 👋</h3>

<p align="center">
I'm Akas, a self-motivated tech enthusiast and full stack web developer.
</p>

<h4 align="center">
💻 full stack developer <a href="https://github.com/machnetinc">@Machnet</a> | 🌱 building <a href="https://github.com/akasrai/daily-quiz-mobile">Daily Quiz</a> | 💬 connect <a href="https://twitter.com/akaskyiar">@akaskyiar</a>
</h4>
<p  align="center">
<a href="https://akasrai.github.io/">https://akasrai.github.io</a>
</p>

<br/>
<h3 align="center">
My Tech Stacks
</h3>

<h3 align="center">
<img src="https://raw.githubusercontent.com/akasrai/akasrai/master/assets/stack-hills.svg" alt="stacks"/>
</h3>

----
Credit: [akasrai](https://github.com/akasrai)

Last Edited on: 19/11/2020