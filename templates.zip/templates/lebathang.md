<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--     <title>README</title> -->
</head>

<body>
    <div align="center">
        <img src="https://media.giphy.com/media/mtmFB01G4rvFEHAsfI/giphy.gif" alt="ảnh gif">
    </div>
    <div align ="center">
        <p>
        <img src="https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black" alt="OS-Linux">
        <img src="https://img.shields.io/badge/Ubuntu-E95420?style=for-the-badge&logo=ubuntu&logoColor=white" alt="ubuntu">
        <!-- </p>
        <p> -->
        <img src="https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white" alt="OS-Windown">
        <img src="https://img.shields.io/badge/Windows_11-0078d4?style=for-the-badge&logo=windows-11&logoColor=white" alt="windows-11">
        </p>
    </div>
    <div align="center">
        <img src="https://komarev.com/ghpvc/?username=lebathang&color=blueviolet&style=flat&label=PROFILE+VIEWS"
            alt="view profile">
    </div>
    <hr width="100%">
    <a href="https://app.daily.dev/lebathang"><img align="right"
            src="https://api.daily.dev/devcards/ee98497bac234fe4886bf7bd42098d69.png?r=etl" width="400"
            alt="Lê Bá Thắng's Dev Card" />
    <div>
            <h3>Hi 👋 my name is Thang 😎</h3>
    </a>
    <ul>
        <li>
            🤗 I'm a newbie in Github 🥳
        </li>
        <li>
            👉 I'm a man student 👨‍🎓
        </li>
        <li>
            📝 And I'm studying English but I'm very lazy 😅
        </li>
        <li>
            🏡 I'm living in a small city in <code>Việt Nam</code> 🇻🇳 👈 🏙️
        </li>
        <li>
            ✍️ I want to study <code>code</code> and <code>how to write a program</code> 👀
        </li>
        <li>
            💯 I'm very happy when you read my profile but I don't think my profile is professtion 🙄
        </li>
        <li>
            💬 this is the first time I create a repository so I hope you will like my profile 👍
        </li>
        <li>
            ❤️ thank you so much for reading it ❤️
        </li>
    </ul>
    </div>
    <!-- <div>
        <h3 align="left">Languages and Tools:</h3>
        <p align="left"> <a href="https://azure.microsoft.com/en-in/" target="_blank" rel="noreferrer"> <img
                    src="https://www.vectorlogo.zone/logos/microsoft_azure/microsoft_azure-icon.svg" alt="azure"
                    width="40" height="40" /> </a> <a href="https://www.w3schools.com/cpp/" target="_blank"
                rel="noreferrer"> <img
                    src="https://raw.githubusercontent.com/devicons/devicon/master/icons/cplusplus/cplusplus-original.svg"
                    alt="cplusplus" width="40" height="40" /> </a> <a href="https://www.w3schools.com/css/"
                target="_blank" rel="noreferrer"> <img
                    src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original-wordmark.svg"
                    alt="css3" width="40" height="40" /> </a> <a href="https://www.docker.com/" target="_blank"
                rel="noreferrer"> <img
                    src="https://raw.githubusercontent.com/devicons/devicon/master/icons/docker/docker-original-wordmark.svg"
                    alt="docker" width="40" height="40" /> </a> <a href="https://git-scm.com/" target="_blank"
                rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg" alt="git"
                    width="40" height="40" /> </a> <a href="https://heroku.com" target="_blank" rel="noreferrer"> <img
                    src="https://www.vectorlogo.zone/logos/heroku/heroku-icon.svg" alt="heroku" width="40"
                    height="40" /> </a> <a href="https://www.w3.org/html/" target="_blank" rel="noreferrer"> <img
                    src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg"
                    alt="html5" width="40" height="40" /> </a> <a href="https://www.java.com" target="_blank"
                rel="noreferrer"> <img
                    src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg"
                    alt="java" width="40" height="40" /> </a> <a href="https://www.linux.org/" target="_blank"
                rel="noreferrer"> <img
                    src="https://raw.githubusercontent.com/devicons/devicon/master/icons/linux/linux-original.svg"
                    alt="linux" width="40" height="40" /> </a> <a href="https://www.microsoft.com/en-us/sql-server"
                target="_blank" rel="noreferrer"> <img
                    src="https://www.svgrepo.com/show/303229/microsoft-sql-server-logo.svg" alt="mssql" width="40"
                    height="40" /> </a>
            <a href="https://getbootstrap.com" target="_blank" rel="noreferrer"> <img
                    src="https://raw.githubusercontent.com/devicons/devicon/master/icons/bootstrap/bootstrap-plain-wordmark.svg"
                    alt="bootstrap" width="40" height="40" /> </a>
            <a href="https://nodejs.org" target="_blank" rel="noreferrer"> <img
                    src="https://raw.githubusercontent.com/devicons/devicon/master/icons/nodejs/nodejs-original-wordmark.svg"
                    alt="nodejs" width="40" height="40" /> </a>
            <a href="https://cloud.google.com" target="_blank" rel="noreferrer"> <img
                    src="https://www.vectorlogo.zone/logos/google_cloud/google_cloud-icon.svg" alt="gcp" width="40"
                    height="40" /> </a>
        </p>
    </div> -->
    <div>
        <h3>Languages:</h3>
        <p style="text-align: left;">
            <img src="https://img.shields.io/badge/C%2B%2B-00599C?style=for-the-badge&logo=c%2B%2B&logoColor=white" alt="C++">
            <img src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white" alt="css">
            <img src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white" alt="html5">
            <img src="https://img.shields.io/badge/PHP-777BB4?style=for-the-badge&logo=php&logoColor=white" alt="PHP">
            <img src="https://img.shields.io/badge/JavaScript-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E" alt="JavaScript">
            <img src="https://img.shields.io/badge/Python-FFD43B?style=for-the-badge&logo=python&logoColor=blue" alt="python">
            <img src="https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=java&logoColor=white" alt="java">
        </p>
        <h3>Tools:</h3>
        <p>
            <img src="https://img.shields.io/badge/Docker-2CA5E0?style=for-the-badge&logo=docker&logoColor=white" alt="docker">
            <img src="https://img.shields.io/badge/Vercel-000000?style=for-the-badge&logo=vercel&logoColor=white" alt="vercel">
            <img src="https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white" alt="git">
            <img src="https://img.shields.io/badge/Heroku-430098?style=for-the-badge&logo=heroku&logoColor=white" alt="heroku">
            <img src="https://img.shields.io/badge/Bootstrap-563D7C?style=for-the-badge&logo=bootstrap&logoColor=white" alt="bootstrap">
            <img src="https://img.shields.io/badge/Azure_DevOps-0078D7?style=for-the-badge&logo=azure-devops&logoColor=white" alt="azure-devops">
            <img src="https://img.shields.io/badge/dev.to-0A0A0A?style=for-the-badge&logo=devdotto&logoColor=white" alt="dev.to">
        </p>
    </div>
    <br>
    <hr width="100%">
    <div>
        <p align=center>
        <div align=center>
            <a href="https://github.com/lebathang/lebathang" title="Go to Source">
                <img align="left" width=390
                    src="https://pr0vjp-github-readme.vercel.app/api?username=lebathang&show_icons=true&theme=midnight-purple&hide_border=true" />
            </a>
            <a href="https://github.com/lebathang/lebathang" title="Go to Source">
                <img align="right" width=390
                    src="https://github-readme-streak-stats.herokuapp.com?user=lebathang&theme=midnight-purple&hide_border=true&date_format=j/n/Y" />
            </a>
        </div>
        <br><br><br><br><br><br><br><br><br>
        <div align="center">
            <img src="https://pr0vjp-github-readme.vercel.app/api/top-langs/?username=lebathang&theme=midnight-purple&&hide_border=truelangs_count=8"
                alt="top langs" />
            </p>
        </div>
        <!-- <div>
            <h2 align="center">📝 Extras 📝</h2>
            <details>
                <summary>Click to expand!</summary>
                <br>
                <p>
                </p>
                <br>
                <p>
                    <img
                        src="https://github-profile-trophy.vercel.app/?username=lebathang&theme=onedark&column=3&margin-w=15&margin-h=15" />
                </p>
                <br>
                <img src="https://metrics.lecoq.io/lebathang?template=classic&activity=1&followup=1&languages=1&lines=1&people=1&achievements=1&activity.limit=5&activity.days=14&activity.filter=all&activity.visibility=all&activity.timestamps=false&languages.colors=github&languages.threshold=0%25&people.limit=28&people.size=28&people.types=followers%2C%20following&people.identicons=true&people.shuffle=true&achievements.threshold=C&achievements.secrets=true&achievements.display=detailed&achievements.limit=0&config.timezone=Asia%2FSaigon&config.twemoji=true"
                    alt="Detailed Github Stats" />
            </details>
        </div> -->
        <!-- phần repo -->
        <div >
            <p align="center">
                <a href="https://github.com/lebathang/QuanLiThuVien"><img src="https://github-readme-stats.vercel.app/api/pin/?username=lebathang&show_icons=true&theme=midnight-purple&hide_border=true&amp;repo=QuanLiThuVien" alt="Readme Card"></a>
                <a href="https://github.com/lebathang/Webside-An-Vat"><img src="https://github-readme-stats.vercel.app/api/pin/?username=lebathang&show_icons=true&theme=midnight-purple&hide_border=true&amp;repo=Webside-An-Vat" alt="Readme Card"></a>
                <a href="https://github.com/lebathang/lebathang"><img src="https://github-readme-stats.vercel.app/api/pin/?username=lebathang&show_icons=true&theme=midnight-purple&hide_border=true&amp;repo=lebathang" alt="Readme Card"></a>
            </p>
        </div>
        <hr width="100%">
        <div>
            <h3 align="center"> 🥰 Connect with me:</h3>
            <p align="center">
                <a href="https://discord.com/channels/@me/835488546897920021">
                    <img src="https://lanyard-profile-readme.vercel.app/api/835488546897920021?animated=true&theme=dark&borderRadius=30px&hideBadges=true&hideDiscrim=true&bg=000000"
                        alt="connect discord">
                </a>
            </p>
            <p align="center">
                ❤️
                <a href="https://www.facebook.com/profile.php?id=100016824016369" target="blank"><img align="center"
                        src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/facebook.svg"
                        alt="lê bá thắng" height="30" width="40" /></a>
                <a href="https://twitter.com/Thang_pr0vjp123" target="blank"><img align="center"
                        src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/twitter.svg"
                        alt="provjp" height="30" width="40" /></a>
                <a href="https://www.instagram.com/lebathang10a6/" target="blank"><img align="center"
                        src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg"
                        alt="lebathang" height="30" width="40" /></a>
                <a href="https://medium.com/@lebathang" target="blank"><img align="center"
                        src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/medium.svg"
                        alt="@lebathang7b" height="30" width="40" /></a>
                <a href="https://stackoverflow.com/users/19120952" target="blank"><img align="center"
                        src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/stack-overflow.svg"
                        alt="user:19120952" height="30" width="40" /></a>
                ❤️
            </p>
        </div>
        <hr width="100%">
        <div>
            <h2 align="center"> 💻 Github Contributions :electron: </h2>
            <br>
            <div align="center">
                <img src="https://github-readme-activity-graph.vercel.app/graph?username=lebathang&color=9745f5&bg_color=000000&line=9745f5&point=ffffff&area_color=000000&hide_border=true&area=true"
                    alt="readme active graph" />
            </div>
</body>

</html>
