<div align="center">
<h1><img src="https://emojis.slackmojis.com/emojis/images/1531849430/4246/blob-sunglasses.gif?1531849430" width="30"/> Hey! Nice to see you.</h1>

<br>

<p> I'm an IT <strong>student</strong> with a passion for building <strong>highly usable web applications</strong>.</p>

<img src="https://github.com/thuanpham2311/thuanpham2311/raw/master/img/ongDev.webp">

<br>

  <a href="https://github.com/thuanpham2311" class="rich-diff-level-one">
    <img src="https://github-readme-stats.vercel.app/api?username=thuanpham2311&icon_color=586069&text_color=586069&bg_color=fff&line_height=30&hide_title=true&title_color=0366d6" alt="Thuan's Stats" >
  </a>

<br>

  <a target="_blank" rel="noopener noreferrer" href= "https://www.youtube.com/channel/UCLAeh5SDjUBOjnE8HTXJLGw">
    <img src="https://github.com/thuanpham2311/thuanpham2311/raw/master/img/icons/youtube.svg" width="26px"/>
  </a>
  &emsp;
  <a target="_blank" rel="noopener noreferrer" href= "https://photos.app.goo.gl/DHmPLryYPK4fp2xDA">
    <img src="https://github.com/thuanpham2311/thuanpham2311/raw/master/img/icons/photos.svg" width="26px"/>
  </a>
  &emsp;
  <a target="_blank" rel="noopener noreferrer" href="http://thuanpham2311.github.io/">
    <img src="https://github.com/thuanpham2311/thuanpham2311/raw/master/img/icons/blog.svg" width="26px"/>
  </a>
  &emsp;
  <a target="_blank" rel="noopener noreferrer" href="https://www.youtube.com/playlist?list=PLiK7Zu7FR9jVJyURcW5nmXveGzJ1DAvf5">
    <img src="https://github.com/thuanpham2311/thuanpham2311/raw/master/img/icons/music.svg" width="26px"/>
  </a>
  &emsp;
  <a target="_blank" rel="noopener noreferrer" href="https://m.me/thuanpham2311">
    <img src="https://github.com/thuanpham2311/thuanpham2311/raw/master/img/icons/chat.svg" width="26px"/>
  </a>
  &emsp;
  <a target="_blank" rel="noopener noreferrer" href="mailto:phamtanthuan2311@gmail.com">
    <img src="https://github.com/thuanpham2311/thuanpham2311/raw/master/img/icons/gmail.svg" width="26px"/>
  </a>
  &emsp;
  <a target="_blank" rel="noopener noreferrer" href="http://linkedin.com/in/thuanpham2311">
    <img src="https://github.com/thuanpham2311/thuanpham2311/raw/master/img/icons/linkedin.svg" width="26px"/>
  </a>
<br>
</div>

------

Credit: [thuanpham2311](https://github.com/thuanpham2311)

Last Edited on: 08/07/2021
