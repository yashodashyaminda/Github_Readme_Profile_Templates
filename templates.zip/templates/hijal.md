### Hey 👋
## This is **hijal** 👋

<p align="center">
<a href="https://app.daily.dev/imh1j4l"><img src="https://api.daily.dev/devcards/9cafd408a0bb4775a0c8de9e649364ae.png?r=lmd" width="400" height="500" alt="Hijikesh Hijal's Dev Card"/></a>
</p>

In my spare time, I am mostly adding new skills to my repertoire and sometimes open-sourcing.

### ⚙️ &nbsp;GitHub Analytics
<p align="">
<a href="https://github.com/AVS1508">
  <img height="180em" src="https://github-readme-stats-eight-theta.vercel.app/api?username=hijal&show_icons=true&theme=algolia&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats-eight-theta.vercel.app/api/top-langs/?username=hijal&layout=compact&langs_count=8&theme=algolia"/>
</a>
</p>
<hr />

[![LinkedIn Connect](https://img.shields.io/badge/%20-Connect-black?color=14171A&labelColor=212121&logo=linkedin&logoColor=ffffff)](https://www.linkedin.com/in/hijikesh-hijal-6115a5135/)
[![Twitter Follow](https://img.shields.io/badge/%20-Connect-black?color=14171A&labelColor=1976d2&logo=twitter&logoColor=ffffff)](https://twitter.com/hiijal)

<hr />

#### About me:
- 👯 I’m looking to collaborate on C, C++, Node.js, React, JavaScript

-----
Credits: [hijal](https://github.com/hijal)

Last Edited on: 07/10/2021