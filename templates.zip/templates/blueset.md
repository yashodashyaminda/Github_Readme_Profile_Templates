![Eana Hufwe](https://github.com/blueset/blueset/raw/cda8ec1230cbee16a3a7dc52a4b2272619588233/EanaHandwritingAnimated.svg)

<p align="center">
A software engineer loves building tools, design, typography and Vocaloid.<br>
<br>
<a href="https://1a23.com">Portfolio Site</a>
 · <a href="https://blog.1a23.com">Blog</a>
 · <a href="https://twitter.com/blueset">Twitter</a>
<br>
<br>
<br>
<br>
</p>

-----
Credits: [Eana Hufwe](https://github.com/blueset)

Last Edited on: 25/11/2020