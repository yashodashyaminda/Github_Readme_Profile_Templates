# 𝗛𝗲𝗹𝗹𝗼! 𝗜'𝗺 小蘿蔔丁

𝑰 ❤️ 𝑭𝒓𝒐𝒏𝒕-𝒆𝒏𝒅 𝑫𝒆𝒗𝒆𝒍𝒐𝒑𝒎𝒆𝒏𝒕!

:computer: 𝑺𝒆𝒏𝒊𝒐𝒓 𝑭𝒓𝒐𝒏𝒕-𝒆𝒏𝒅 𝑬𝒏𝒈𝒊𝒏𝒆𝒆𝒓, 𝒄𝒖𝒓𝒓𝒆𝒏𝒕𝒍𝒚 𝒃𝒂𝒔𝒆𝒅 𝒊𝒏 𝑩𝒆𝒊𝒋𝒊𝒏𝒈, 𝒂𝒕 𝑱𝑫.𝒄𝒐𝒎. 

:vulcan_salute: 𝑰 𝒑𝒖𝒕 𝒎𝒐𝒔𝒕𝒍𝒚 𝒐𝒇 𝒎𝒚 𝒇𝒐𝒄𝒖𝒔 𝒐𝒏 𝒘𝒆𝒃 𝒅𝒆𝒗𝒆𝒍𝒐𝒑𝒎𝒆𝒏𝒕 𝒘𝒊𝒕𝒉 𝑱𝒂𝒗𝒂𝑺𝒄𝒓𝒊𝒑𝒕, 𝒂𝒏𝒅 𝑰'𝒎 𝒂 𝑽𝒖𝒆.𝒋𝒔 𝒏𝒆𝒓𝒅. 

:writing_hand: 𝑰 𝒍𝒐𝒗𝒆 𝒔𝒉𝒂𝒓𝒊𝒏𝒈 𝒇𝒓𝒐𝒏𝒕-𝒆𝒏𝒅 𝒕𝒆𝒄𝒉 𝒔𝒕𝒂𝒄𝒌, 𝒚𝒐𝒖 𝒄𝒂𝒏 𝒄𝒉𝒆𝒄𝒌 𝒎𝒚 [monthly](http://github.com/xiaoluoboding/monthly) 𝒓𝒆𝒑𝒐𝒔 𝒄𝒐𝒍𝒍𝒆𝒄𝒕𝒊𝒐𝒏 𝒇𝒐𝒓 𝒎𝒐𝒓𝒆 𝒅𝒆𝒕𝒂𝒊𝒍𝒔.

## 𝗠𝘆 𝗧𝗲𝗰𝗸 𝗦𝘁𝗮𝗰𝗸

<table>
  <tbody>
    <tr valign="top">
      <td width="25%" align="center">
        <span>𝗛𝗧𝗠𝗟𝟱</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/html-5.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗖𝗦𝗦𝟯</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/css-3.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗝𝗮𝘃𝗮𝗦𝗰𝗿𝗶𝗽𝘁</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/javascript.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗩𝘂𝗲</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/vue.svg">
      </td>
    </tr>
    <tr valign="top">
      <td width="25%" align="center">
        <span>𝗪𝗲𝗯𝗽𝗮𝗰𝗸</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/webpack.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗘𝘀𝗹𝗶𝗻𝘁</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/eslint.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗚𝗶𝘁</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/git-icon.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗩𝗦 𝗖𝗼𝗱𝗲</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/visual-studio-code.svg">
      </td>
    </tr>
    <tr valign="top">
      <td width="25%" align="center">
        <span>𝗟𝗲𝘀𝘀</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/less.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗦𝗮𝘀𝘀/𝗦𝗖𝗦𝗦</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/sass.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗧𝗮𝗶𝗹𝘄𝗶𝗻𝗱𝗖𝘀𝘀</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/tailwindcss-icon.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗡𝗲𝘁𝗹𝗶𝗳𝘆</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/netlify.svg">
      </td>
    </tr>
  </tbody>
</table>

## 𝗩𝗶𝘀𝗶𝘁𝗼𝗿𝘀

![visitors](https://visitor-badge.glitch.me/badge?page_id=xiaoluoboding.xiaoluoboding)

-----
Credits: [xiaoluoboding](https://github.com/xiaoluoboding)

Last Edited on: 30/08/2020