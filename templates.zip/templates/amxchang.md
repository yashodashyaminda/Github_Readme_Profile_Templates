![Banner](https://raw.githubusercontent.com/amxchang/amxchang/master/profileavatarbanner.png)

I'm a high school student who lives in the United States. I'm learning how to code. I love making and designing webpages with HTML and CSS (and possible JavaScript in the future).  It's fun to code something that anyone on the web can easily see. I also enjoy programming in C++ and Python because they challenge me more. I love it when I can finally solve a difficult problem.

For my programming projects, I usually only upload to Github once I make significant progress. For markdown files, I make commits much more often. Feel free to create a pull request to contribute to any of my repositories.

- 🌱 I’m currently learning HTML, CSS, Python, and C++.
- 🔭 I’m currently working on creating webpages and learning how to progam.
- 😀 I like to crochet, code, read, and draw in my free time.
- 💬 Ask me about fountain pens.
- ⚡ Fun fact: My first line of code was not "Hello World!"

[![Ava's Github Stats](https://github-readme-stats.vercel.app/api?username=amxchang)](https://github.com/anuraghazra/github-readme-stats)

-----
Credits: [amxchang](https://github.com/amxchang)

Last Edited on: 30/08/2020