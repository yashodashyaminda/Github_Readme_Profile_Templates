# Hi, this is emrah!
A multipotentialite research assistant who is currently working on Fog Computing and Blockchain scalability at NMSU. Besides them, I have a great interest in Cybersecurity and Machine Learning! I love to use these skills to solve challenging research problems.


![image](https://media.giphy.com/media/4TtTVTmBoXp8txRU0C/giphy.gif)

-----
Credits: [emrahsariboz](https://github.com/emrahsariboz)

Last Edited on: 30/08/2020