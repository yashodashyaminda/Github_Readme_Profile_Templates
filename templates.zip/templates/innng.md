<div align="center">
<img width="800" src="https://raw.githubusercontent.com/innng/innng/master/assets/header.gif"/>
</div>

## <img height="30" src="https://raw.githubusercontent.com/innng/innng/master/assets/soulgem-madoka.gif"/> About me
Non binary person • Brazilian • Back-end Software Engineer/DevOps • Computer Science undergraduate 

## <img height="30" src="https://raw.githubusercontent.com/innng/innng/master/assets/soulgem-homura.gif"/> I like these technologies
Python • Rust • Functional programming • CI/CD • Ansible • Cloud computing

## <img height="30" src="https://raw.githubusercontent.com/innng/innng/master/assets/soulgem-mami.gif"/> I love
Powerful women • Learning, exploring and challenging myself • Design, customization and colors • Games and animations • Linux

## <img height="30" src="https://raw.githubusercontent.com/innng/innng/master/assets/soulgem-kyoko.gif"/> On my free time I like to
Watch anime • Customize my Arch installation • Code • Listen to music • Play games

## <img height="30" src="https://raw.githubusercontent.com/innng/innng/master/assets/soulgem-sayaka.gif"/> Links
[![](https://img.shields.io/badge/-linkedin-0073B1?style=flat-square)](http://linkedin.com/in/ingridrosselis)
[![](https://img.shields.io/badge/-twitter-1C9CEA?style=flat-square)](https://twitter.com/itsinnng)
[![](https://img.shields.io/badge/-meetup-EE3E5D?style=flat-square)](https://www.meetup.com/members/262353843/)
[![](https://img.shields.io/badge/-resume-332B40?style=flat-square)](https://resume.io/r/zUDFmwciy)
[![](https://img.shields.io/badge/-badges-2D4E00?style=flat-square)](https://www.youracclaim.com/users/ingridrosselis/badges)

-----
Credits: [innng](https://github.com/innng)

Last Edited on: 30/08/2020