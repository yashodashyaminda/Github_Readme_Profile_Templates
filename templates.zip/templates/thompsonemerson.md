<p align="center">
  <img src="https://github.com/thompsonemerson/thompsonemerson/raw/master/cover-thompson.png" />
</p>

```js
import SoftwareDeveloper from 'thompsonemerson';

class Bio extends SoftwareDeveloper {
  name     = 'Emerson Thompson';
  title    = 'Software Engineer';
  company  = 'Pipoca Digital | Remote';
  location = 'Fortaleza, CE';
}

class Skills extends SoftwareDeveloper {
  languages  = ['JavaScript', 'PHP'];
  databases  = ['MySQL', 'MongoDB', 'PostgreSQL'];
  frameworks = ['React', 'React Native', 'Angular', 'GraphQL'];
}
```
----
Credit: [thompsonemerson](https://github.com/thompsonemerson)

Last Edited on: 23/09/2020