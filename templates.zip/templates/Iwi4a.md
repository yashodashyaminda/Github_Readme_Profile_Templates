![alt README header](https://raw.githubusercontent.com/Iwi4a/iwi4a/master/assets/header.png)

## Web Developer (JS, NodeJS & Python)

🔭 Currently working at Global, a British media company. I work with great people and we are using great technologies! 

Long story short:

🥑 Eat 💻 Code 💪🏽 Train ♻️ Repeat


🌎 Check my [portfolio](https://www.ivelin.me/)

I'm always doing some side projects, but I can't be bothered to keep my portfolio up to date. 

Feel free to reach out 💬
<!--
**Iwi4a/iwi4a** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->

<div align="center" style="background:#414a50; padding: 25px 0;">
    <a href="https://twitter.com/ThisIsIvoLondon">
        <img src="https://raw.githubusercontent.com/Iwi4a/iwi4a/master/assets/twitter.svg" alt="Follow me on twitter">
    </a>
     <a href="https://www.linkedin.com/in/ivelin-iliev-16272baa/">
        <img src="https://raw.githubusercontent.com/Iwi4a/iwi4a/master/assets/linkedin.svg" alt="Connect on Linkedin">
    </a>
</div>

-----
Credits: [Ivelin Iliev](https://github.com/Iwi4a)

Last Edited on: 25/11/2020