## Hi there, I'm Akash Patel 

<p align="center">
<img width="20%" src="https://img.icons8.com/ios-filled/96/000000/programming.png"/>
</p>


- I'm **Developer** | **Programmer** | **Learner**
- Currently Learning **Java**, **Python**, **Web Development** And **Machine Learning**
- Willing to contribute more and more in **Open Source Projects**


### Feel Free to Contact me.....

<p align="center">
	<a href="https://github.com/imakash3011"><img alt="github" width="10%" style="padding:5px" src="https://img.icons8.com/clouds/100/000000/github.png"/></a>
	<a href="https://www.linkedin.com/in/imakash3011/"><img alt="linkedin" width="10%" style="padding:5px" src="https://img.icons8.com/clouds/100/000000/linkedin.png"/></a>
	<a href="https://www.facebook.com/imakash3011/"><img alt="facebook" width="10%" style="padding:5px" src="https://img.icons8.com/clouds/100/000000/facebook-new.png"/></a>
	<a href="https://www.instagram.com/imakash3011/"><img alt="instagram" width="10%" style="padding:5px" src="https://img.icons8.com/clouds/100/000000/instagram.png"/></a>
	<a href="https://twitter.com/imakash3011"><img alt="twitter" width="10%" style="padding:5px" src="https://img.icons8.com/clouds/100/000000/twitter.png"/></a>
</p>

### Programming Languages....

<p align="center">
	<img width="10%" style="padding:5px" src="https://img.icons8.com/color/144/000000/java-coffee-cup-logo.png"/>
	<img width="10%" style="padding:5px" src="https://img.icons8.com/color/144/000000/python.png"/>
	<img width="10%" style="padding:5px" src="https://img.icons8.com/color/144/000000/javascript.png"/>
</p>

#### Profile views counter
![Visitor Count](https://profile-counter.glitch.me/{imakash3011}/count.svg)


----
Credit: [imakash3011](https://github.com/imakash3011)

Last Edited on: 19/11/2020