<h1 align="center">Hi 👋, I'm Ketan @deprexxtion</h1>
<h3 align="center">Flutter developer from Kolkata, India &#127470;&#127475</h3>
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

<p align="left"> <img src="https://komarev.com/ghpvc/?username=dexprexxtion&label=Profile%20views&color=8caaee&style=for-the-badge" alt="dexprexxtion's profile views" /> </p>

<br>

[![Ketan's GitHub stats](https://github-readme-stats.vercel.app/api?username=dexprexxtion&includeallcommits=true&show_icons=true&theme=tokyonight)](https://github.com/anuraghazra/github-readme-stats)
[![Ketan's Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=dexprexxtion&layout=compact&theme=tokyonight&langs_count=8)](https://github.com/anuraghazra/github-readme-stats)


## <img src="https://media2.giphy.com/media/QssGEmpkyEOhBCb7e1/giphy.gif?cid=ecf05e47a0n3gi1bfqntqmob8g9aid1oyj2wr3ds3mg700bl&rid=giphy.gif" width ="25"><b> Skills</b>
<br>

<p align="center">

- **Languages**:
  
  ![Dart](https://img.shields.io/badge/Dart-beginnner-blue?style=for-the-badge&logo=dart&logoColor=white)
  ![Python](https://img.shields.io/badge/Python-beginnner-%2314354C?style=for-the-badge&logo=python&logoColor=white)
  
  <br>
  
- **Frameworks**:
  
  ![Flutter](https://img.shields.io/badge/Flutter-beginnner-%232370ED?style=for-the-badge&logo=flutter&logoColor=white)
  
- **Software**:
  
  ![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)
  ![Pop!_OS](https://img.shields.io/badge/-Pop!__OS-cyan?style=for-the-badge&logo=popos&logoColor=black)
  ![Visual Studio Code](https://img.shields.io/badge/Visual%20Studio%20Code-blue?style=for-the-badge&logo=visualstudiocode&logoColor=white)
  ![Github](https://img.shields.io/badge/Github-black?style=for-the-badge&logo=github&logoColor=white)
  ![Git](https://img.shields.io/badge/Git-orange?style=for-the-badge&logo=github&logoColor=white)
  ![Terminal](https://img.shields.io/badge/Terminal-%23054020?style=for-the-badge&logo=gnu-bash&logoColor=white)
  
- **Hardware**:
  
  ![Intel](https://img.shields.io/badge/Intel-blue?style=for-the-badge&logo=intel&logoColor=white)
  ![Nvidia](https://img.shields.io/badge/Nvidia-deepgreen?style=for-the-badge&logo=nvidia&logoColor=white)
  ![Dell](https://img.shields.io/badge/dell-black?style=for-the-badge&logo=dell&logoColor=white)
  ![Logitech](https://img.shields.io/badge/logitech-white?style=for-the-badge&logo=logitech&logoColor=black)
  

 <img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
  
   <div align="center"  class="icons-social" style="margin-left: 10px;">
     <a style="margin-left: 10px;" target="_blank" href="https://github.com/dexprexxtion">
		<img src="https://img.icons8.com/doodle/40/000000/github--v1.png"></a>
     <a style="margin-left: 10px;" target="_blank" href="https://twitter.com/dexprexxtion">
			<img src="https://img.icons8.com/doodle/1x/twitter-squared--v2.png" ></a>
     <a style="margin-left: 10px;" target="_blank" href="mailto://ketanchowdhury@protonmail.com">
       <img src="https://seeklogo.com/images/G/gmail-new-2020-logo-32DBE11BB4-seeklogo.com.png" height="40" width="50">

------

<br>

Credit: [Ketan Chowdhury](https://github.com/dexprexxtion)

Last Edited on: 27/02/2023