### Hi there 👋
* Welcome to my pond, feel free to check out my 🌐 [website](https://bluexguardian.com) :P.

#### Current Working on
* [Real-InfoState](https://github.com/UTS-ASD2020-G1/real-infostate) - *A new concept on real-estate and lifestyle coded in ReactJS*
* [SimPlan](https://github.com/blue-1ms/Simplan) - *A C# WPF Program to assist student's with their semester planning.*
* [Tekh](https://github.com/ShaanCoding/Tekh) - *A discord bot written in Java*
* [the24 by vicr123](https://github.com/vicr123/the24) | [theDesk by vicr123](https://github.com/vicr123/thedesk) | [theBeat by vicr123](https://github.com/vicr123/theBeat) *Translation for Slovak and Simplified Chinese*

#### I work with
* ☁ AWS EC2 
* 💻 Python | C# | C++ | Java | React

#### Some Completed Stuff
* [Pay Roll Calculator](https://github.com/blue-1ms/Simple-Pay-Roll-Calculator) - *A simple payroll calculator written in Python*
* [bluexguardian.com](https://bluexguardian.com) - *My domain hosted on GitHub*
* [PigeonTracker](https://github.com/blue-1ms/PigeonTracker) - *A C# Program to help keep track of your owned games :P (made in 2018 so needs update)*

 #### Stats
[![Stats](https://github-readme-stats.vercel.app/api?username=blue-1ms)](https://github.com/blue-1ms)

#### Other Social Medias
🐦 [Twitter](https://twitter.com/rainlink) | 💼 [LinkedIn](https://www.linkedin.com/in/oscar-1ms/) | 📧 [Email](mailto:blue@bluexguardian.com)
 

<!--
**blue-1ms/blue-1ms** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.
-->
-----
Credits: [blue-1ms](https://github.com/blue-1ms)

Last Edited on: 19/11/2020