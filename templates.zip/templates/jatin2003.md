<h2 align="center">👋 Hello! I'm Jatin.</h2>
<p align="center">
  <a href="https://jatinrao.dev">Blog</a> •
  <a href="https://twitter.com/iamjatinrao">Twitter</a>
</p>

- 🌱 I’m currently learning **JavaScript and Python**
- 💬 Ask me about **Python, JavaScript, Content Creation**
- 📫 How to reach me: [@iamjatinrao](https://twitter.com/iamjatinrao) on Twitter

-----

### 📝 Latest Blog Posts

<!-- BLOG-POST-LIST:START -->
- [4 Games to Level Up Your CSS Skills](https://jatinrao.dev/4-games-to-level-up-your-css-skills)
- [Beginners Guide To Markdown](https://jatinrao.dev/beginners-guide-to-markdown)
- [12 HTML Tags You Don't Know](https://jatinrao.dev/12-html-tags-you-dont-know)
- [Monthly Reflection - August 2020](https://jatinrao.dev/monthly-reflection-august-2020)
- [Fear Of Missing Out As A Developer](https://jatinrao.dev/fear-of-missing-out-as-developer)
<!-- BLOG-POST-LIST:END -->

-----

<img align="center" alt="Jatin's Github Stats" src="https://github-readme-stats.vercel.app/api?username=jatin2003&show_icons=true&hide_border=true" />

<p align="center"> 
  Visitor count<br>
  <img src="https://profile-counter.glitch.me/jatin2003/count.svg" />
</p>

-----
Credits: [Jatin Rao](https://github.com/jatin2003)

Last Edited on: 30/11/2020