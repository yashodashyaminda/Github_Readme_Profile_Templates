### Here's what I'm working on 🤓<br>
 


- 🔭 I’m currently working on ... <b>Machine Learning & Web Development</b>
- 🌱 I’m currently learning ... <b>Machine Learning</b>
- 👯 I’m looking to collaborate on ... <b>Python projects  & Web projects</b>
- 🤔 I’m looking for help with ... <b>Deep learning</b>
- 💬 Ask me about ... <b>Full stack web development and Fitness</b>
- 📫 How to reach me: ...<br><br>
    [Youtube](https://www.youtube.com/channel/UCbyoTZ9guFWEC5BaKRkV9Aw)<br>
    [Facebook](https://web.facebook.com/pavstar619)<br>
    [LinkedIn](https://www.linkedin.com/in/pavel-rahman/)<br>
    [Instagram](https://www.instagram.com/pavstar619/)<br>
    
- 😄 Pronouns: ... He/ Him
- ⚡ Fun fact: ... I can do handstands

<br> 
<image align="center" src="https://github-readme-stats.vercel.app/api?username=pavstar619&theme=dracula"> 
<br> 
 
 
-----
Credits: [pavstar619](https://github.com/pavstar619)

Last Edited on: 19/11/2020