<h1 align="center">Hi, visitor, I'm Banerjee. Welcome to my profile</h1>
<p align="center">
	<a href="https://www.instagram.com/debugginglife_02/" target="blank"
		><img
			align="center"
			src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTjPiD9d7LK2UK72ECs4DX5cJ1sH4x6UQBKRg&usqp=CAU"
			alt="kaswebsite"
			height="100"
			width="100"
	/></a>
</p>

<h3 align="center"A student who can just code..</h3>
<p align="center">
	<img
		align="center"
		src="https://img.shields.io/badge/Profile%20Views-226-blue"
	/>
	<img
		align="center"
		src="https://img.shields.io/badge/In%20all%20github%20repositories%20I%20have%20written-10756%20lines%20of%20code-blue"
	/>
</p>
<h2 align="center">Personal Details</h2>
<p align="center">
	1. Learning programming languages: HTML, CSS, JavaScript, C,C++, Python,
	Bash/Shell,Angular<br>
	2. Hobby: Reading books, Listen music, Play games.<br> 3. Loves to: Create Fake Scenarios inside head and of course something new techy, <br> 4. Collections of : 
	ISO, MP3, EXE, JPEG, PDF.<br>
	6.Bit of photographer<br> 

</p>
<h2 align="center">My Github Stats</h2>
<p align="center">
	<img
		align="center"
		src="https://github-readme-stats.vercel.app/api/top-langs/?username=soham4abc&&layout=compact&bg_color=0,73FA79,73FDFF,7A81FF&theme=graywhite"
	/>
	<img
		align="center"
		src="https://github-readme-stats.vercel.app/api?username=soham4abc&count_private=true&show_icons=trueline_height=21&bg_color=0,EC6C6C,FFD479,FFFC79,73FA79&theme=graywhite"
	/>
	<img align="center" src="https://github-readme-streak-stats.herokuapp.com/?user=soham4abc&theme=dracula">
	<img
		align="center"
		src="https://github-profile-trophy.vercel.app/?username=soham4abc&theme=onedark"
	/>
</p>
------

Credits: [soham4abc](https://github.com/soham4abc)

Last Edited on: 16/05/2021
