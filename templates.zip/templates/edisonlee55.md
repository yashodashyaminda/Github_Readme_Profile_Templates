<p align="center">
  <a href="https://www.edisonlee55.com"><img src="https://cdn.edisonlee55.com/edisonlee55/resources/photo/2020edisonlee55banner.png" alt="edisonlee55 Banner"></a>
</p>

<h1 align="center">Hi, I'm <a href="https://www.edisonlee55.com">Edison Lee</a>!</h1>
<h1 align="center">Welcome to my GitHub profile~ OwO</h1>

<p align="center">
  <a href="https://github.com/edisonlee55"><img src="https://github-readme-stats.vercel.app/api?username=edisonlee55&hide_border=true&show_icons=true" alt="edisonlee55's github stats"></a>
</p>

<p align="center">
  <strong><a href="https://www.edisonlee55.com">Official Website</a></strong> |
  <strong><a href="https://twitter.com/edisonlee55">Twitter</a></strong> |
  <strong><a href="https://discord.gg/nYXzaUS">Discord</a></strong> |
  <strong><a href="https://www.linkedin.com/in/edisonlee55">LinkedIn</a></strong> |
  <strong><a href="https://www.twitch.tv/edisonlee55">Twitch</a></strong>
</p>

<p align="center">❤ I'm currently working on Software, Anime / Manga, Game Dev, and Content Creation.</p>

<!--
**edisonlee55/edisonlee55** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->

-----
Credits: [edisonlee55](https://github.com/edisonlee55)

Last Edited on: 30/08/2020